const express=require('express'),http=require('http'),{Server}=require('socket.io'),fs=require('fs'),path=require('path');
const app=express(),server=http.createServer(app),io=new Server(server);
app.use(express.static(path.join(__dirname,'public')));
const questions=JSON.parse(fs.readFileSync(path.join(__dirname,'public/questions.json'),'utf8'));
const rooms=new Map();const code=()=>Math.random().toString(36).slice(2,7).toUpperCase();
function view(r){return [...r.players.values()].map(p=>({id:p.id,name:p.name,team:p.team,host:p.host}))}
function broadcast(r){io.to(r.code).emit('roomUpdate',{code:r.code,players:view(r)})}
function emitQuestion(r){if(r.q>=30){io.to(r.code).emit('gameOver',{red:r.scores.rojo,blue:r.scores.azul});r.started=false;return}
 const q=questions[r.q];r.answers.clear();r.remaining=10;
 io.to(r.code).emit('question',{number:r.q+1,seconds:10,question:q[0],options:q.slice(1,5),imageLabel:'Imagen microscópica ilustrativa: '+q[6],imageIndex:r.q%16});
 clearInterval(r.timer);r.timer=setInterval(()=>{r.remaining--;io.to(r.code).emit('tick',r.remaining);if(r.remaining<=0){clearInterval(r.timer);reveal(r)}},1000);
}
function reveal(r){if(r.revealed)return;r.revealed=true;clearInterval(r.timer);const q=questions[r.q];for(const p of r.players.values()){if(!r.answers.has(p.id))io.to(p.id).emit('answerResult',{correct:false,correctAnswer:q[q[5]+1],red:r.scores.rojo,blue:r.scores.azul})}io.to(r.code).emit('scoreUpdate',{red:r.scores.rojo,blue:r.scores.azul});setTimeout(()=>{r.q++;r.revealed=false;emitQuestion(r)},2300)}
io.on('connection',s=>{
 s.on('createRoom',({name},cb)=>{let c=code();while(rooms.has(c))c=code();let p={id:s.id,name:String(name).slice(0,18),team:'rojo',host:true};let r={code:c,host:s.id,players:new Map([[s.id,p]]),scores:{rojo:0,azul:0},q:0,answers:new Map(),started:false,revealed:false,timer:null};rooms.set(c,r);s.join(c);cb({ok:true,code:c,playerId:s.id,players:view(r)});broadcast(r)});
 s.on('joinRoom',({name,code:c},cb)=>{let r=rooms.get(String(c).toUpperCase());if(!r)return cb({ok:false,error:'No existe esa sala. Revisa el código.'});if(r.started)return cb({ok:false,error:'La partida ya comenzó.'});if(r.players.size>=6)return cb({ok:false,error:'La sala está llena (6 jugadores).'});let team=[...r.players.values()].filter(p=>p.team==='rojo').length<3?'rojo':'azul';let p={id:s.id,name:String(name).slice(0,18),team,host:false};r.players.set(s.id,p);s.join(r.code);cb({ok:true,code:r.code,playerId:s.id,players:view(r)});broadcast(r)});
 s.on('startGame',({code:c},cb)=>{let r=rooms.get(c);if(!r||r.host!==s.id)return cb({ok:false,error:'Solo la anfitriona puede iniciar.'});if(r.players.size<2)return cb({ok:false,error:'Se necesitan al menos 2 participantes.'});if(![...r.players.values()].some(p=>p.team==='azul'))return cb({ok:false,error:'Debe haber participantes en ambos equipos.'});r.started=true;r.q=0;cb({ok:true});io.to(c).emit('gameStarted');emitQuestion(r)});
 s.on('answer',({code:c,index},cb)=>{let r=rooms.get(c),p=r&&r.players.get(s.id);if(!r||!p||!r.started||r.revealed||r.answers.has(s.id))return;if(!Number.isInteger(index)||index<0||index>3)return;r.answers.set(s.id,index);let q=questions[r.q],correct=index===q[5];if(correct)r.scores[p.team]+=100;s.emit('answerResult',{correct,correctAnswer:q[q[5]+1],red:r.scores.rojo,blue:r.scores.azul});io.to(c).emit('scoreUpdate',{red:r.scores.rojo,blue:r.scores.azul});if(r.answers.size===r.players.size)reveal(r)});
 s.on('disconnect',()=>{for(const r of rooms.values()){if(r.players.delete(s.id)){broadcast(r);if(r.host===s.id){io.to(r.code).emit('notice','La anfitriona se desconectó. La sala se cerrará.');clearInterval(r.timer);rooms.delete(r.code)}break}}});
});
const PORT=process.env.PORT||3000;server.listen(PORT,()=>console.log('RETO DE MICROBIOLOGÍA en puerto '+PORT));
